class Book {
  String? id;
  String title;
  String author;
  String genre;
  bool isRead;

  Book(
      {this.id,
      required this.title,
      required this.author,
      required this.genre,
      required this.isRead});

  factory Book.fromJson(Map<String, dynamic> json) => Book(
        id: json['id'],
        title: json['title'],
        author: json['author'],
        genre: json['genre'],
        isRead: json['isRead'],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'author': author,
        'genre': genre,
        'isRead': isRead,
      };
}
