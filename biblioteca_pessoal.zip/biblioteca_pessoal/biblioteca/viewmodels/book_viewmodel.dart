import '../models/book.dart';
import '../services/firebase_service.dart';

class BookViewModel extends ChangeNotifier {
  final FirebaseService _firebaseService = FirebaseService();
  List<Book> _books = [];

  List<Book> get books => _books;

  Future<void> fetchBooks() async {
    _books = await _firebaseService.fetchBooks();
    notifyListeners();
  }

  Future<void> addBook(Book book) async {
    await _firebaseService.addBook(book);
    await fetchBooks();
  }

  Future<void> updateBook(Book book) async {
    await _firebaseService.updateBook(book);
    await fetchBooks();
  }

  void notifyListeners() {}
}

class ChangeNotifier {}
