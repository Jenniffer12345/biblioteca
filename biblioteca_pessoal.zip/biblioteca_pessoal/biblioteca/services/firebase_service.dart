import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/book.dart';

class FirebaseService {
  static const String baseUrl = 'https://<your-database-name>.firebaseio.com';

  Future<List<Book>> fetchBooks() async {
    final response = await http.get(Uri.parse('$baseUrl/books.json'));
    if (response.statusCode == 200) {
      final data = json.decode(response.body) as Map<String, dynamic>;
      return data.entries.map((e) {
        final book = Book.fromJson(e.value);
        book.id = e.key;
        return book;
      }).toList();
    }
    return [];
  }

  Future<void> addBook(Book book) async {
    await http.post(
      Uri.parse('$baseUrl/books.json'),
      body: json.encode(book.toJson()),
    );
  }

  Future<void> updateBook(Book book) async {
    await http.put(
      Uri.parse('$baseUrl/books/${book.id}.json'),
      body: json.encode(book.toJson()),
    );
  }
}
