import 'viewmodels/book_viewmodel.dart';
import 'views/list_books.dart';

void main() {
  runApp(MyApp());
}

void runApp(MyApp myApp) {}

class MyApp extends StatelessWidget {
  Widget build(BuildContext context) {
    var themeData = ThemeData();
    return ChangeNotifierProvider(
      create: (_) => BookViewModel()..fetchBooks(),
      child: MaterialApp(
        title: 'Biblioteca Pessoal',
        theme: themeData,
        home: ListBooks(),
      ),
    );
  }

  MaterialApp(
      {required String title, required theme, required ListBooks home}) {}

  ChangeNotifierProvider(
      {required BookViewModel Function(dynamic _) create, required child}) {}
}

class Widget {}

class BuildContext {}

class Colors {
  static var blue;
}

class ThemeData {}
