import '../models/book.dart';
import '../viewmodels/book_viewmodel.dart';
import 'add_book.dart'; // Importar a tela AddBook
import 'edit_book.dart'; // Importar a tela EditBook

class ListBooks extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Biblioteca Pessoal')),
      body: Consumer<BookViewModel>(
        builder: (context, model, child) {
          return ListView.builder(
            itemCount: model.books.length,
            itemBuilder: (context, index) {
              final book = model.books[index];
              return ListTile(
                title: Text(book.title),
                subtitle: Text(book.author),
                trailing: Text(book.isRead ? 'Lido' : 'Não lido'),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => EditBook(book: book),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => AddBook()),
          );
        },
        child: Icon(Icons.add),
      ),
    );
  }
}

class StatelessWidget {}
