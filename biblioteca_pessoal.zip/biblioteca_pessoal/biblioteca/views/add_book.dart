import 'dart:html';

import '../main.dart';
import '../models/book.dart';
import '../viewmodels/book_viewmodel.dart';
import 'list_books.dart';

class AddBook extends StatelessWidget {
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _authorController = TextEditingController();
  final TextEditingController _genreController = TextEditingController();
  bool _isRead = false;

  Widget build(BuildContext context) {
    var textField = TextField(
      controller: _titleController,
      decoration: InputDecoration(labelText: 'Título'),
    );
    var padding = Padding(
      padding: EdgeInsets.all(16.0),
      child: Column(
        children: [
          textField,
          TextField(
            controller: _authorController,
            decoration: InputDecoration(labelText: 'Autor'),
          ),
          TextField(
            controller: _genreController,
            decoration: InputDecoration(labelText: 'Gênero'),
          ),
          SwitchListTile(
            title: Text('Lido'),
            value: _isRead,
            onChanged: (value) {
              _isRead = value;
            },
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () async {
              final book = Book(
                title: _titleController.text,
                author: _authorController.text,
                genre: _genreController.text,
                isRead: _isRead,
              );
              await Provider.of<BookViewModel>(context, listen: false)
                  .addBook(book);
              Navigator.pop(context);
            },
            child: Text('Adicionar'),
          ),
        ],
      ),
    );
    return Scaffold(
      appBar: AppBar(title: Text('Adicionar Livro')),
      body: padding,
    );
  }

  Widget Scaffold({required appBar, required body}) {}
}

class InputDecoration {}

class TextField {}

class Column {}

class EdgeInsets {
  static all(double d) {}
}

class Padding {}

class AppBar {}

class TextEditingController {}
