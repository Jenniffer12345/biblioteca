// ignore_for_file: public_member_api_docs, sort_constructors_first

import '../models/book.dart';
import '../viewmodels/book_viewmodel.dart';
import 'add_book.dart';

class EditBook extends StatefulWidget {
  final Book book;

  EditBook({
    Set? key,
    required this.book,
  }) : super(key: key);

  @override
  _EditBookState createState() => _EditBookState();
}

class StatefulWidget {}

class _EditBookState extends State<EditBook> {
  late TextEditingController _titleController;
  late TextEditingController _authorController;
  late TextEditingController _genreController;
  late bool _isRead;

  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.book.title);
    _authorController = TextEditingController(text: widget.book.author);
    _genreController = TextEditingController(text: widget.book.genre);
    _isRead = widget.book.isRead;
  }

  @override
  void dispose() {
    _titleController.dispose();
    _authorController.dispose();
    _genreController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Editar Livro')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _titleController,
              decoration: InputDecoration(labelText: 'Título'),
            ),
            TextField(
              controller: _authorController,
              decoration: InputDecoration(labelText: 'Autor'),
            ),
            TextField(
              controller: _genreController,
              decoration: InputDecoration(labelText: 'Gênero'),
            ),
            SwitchListTile(
              title: Text('Lido'),
              value: _isRead,
              onChanged: (value) {
                setState(() {
                  _isRead = value;
                });
              },
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                final updatedBook = Book(
                  id: widget.book.id,
                  title: _titleController.text,
                  author: _authorController.text,
                  genre: _genreController.text,
                  isRead: _isRead,
                );
                await Provider.of<BookViewModel>(context, listen: false)
                    .updateBook(updatedBook);
                Navigator.pop(context);
              },
              child: Text('Salvar'),
            ),
          ],
        ),
      ),
    );
  }
}

class State {}
